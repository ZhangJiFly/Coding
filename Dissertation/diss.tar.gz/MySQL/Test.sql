DECLARE @value1 nvarchar(15);
DECLARE @value2 nvarchar(15);
DECLARE curs CURSOR
	FOR SELECT Matric FROM Student

SET @value1 = '';
SET @value2 = '';

WHILE 

UPDATE Student;
SET Username=value1;
WHERE Matric=@value2;