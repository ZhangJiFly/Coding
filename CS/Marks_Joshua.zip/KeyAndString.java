
public class KeyAndString {
	private int key;
	private String sb;
	
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	public String getSb() {
		return sb;
	}
	public void setSb(String sb) {
		this.sb = sb;
	}
	public KeyAndString(int key, String sb) {
		this.key = key;
		this.sb = sb;
	}
	
	
}
