javac -cp . fileCrawler.java
